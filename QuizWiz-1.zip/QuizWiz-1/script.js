// Quiz Application JavaScript

class QuizApp {
    constructor() {
        this.questions = [
            {
                question: "What is the capital of France?",
                options: ["London", "Berlin", "Paris", "Madrid"],
                correct: 2
            },
            {
                question: "Which planet is known as the Red Planet?",
                options: ["Venus", "Mars", "Jupiter", "Saturn"],
                correct: 1
            },
            {
                question: "What is the largest mammal in the world?",
                options: ["African Elephant", "Blue Whale", "Giraffe", "Polar Bear"],
                correct: 1
            },
            {
                question: "In which year did World War II end?",
                options: ["1944", "1945", "1946", "1947"],
                correct: 1
            },
            {
                question: "What is the chemical symbol for gold?",
                options: ["Go", "Gd", "Au", "Ag"],
                correct: 2
            },
            {
                question: "Which is the longest river in the world?",
                options: ["Amazon River", "Nile River", "Yangtze River", "Mississippi River"],
                correct: 1
            },
            {
                question: "What is the smallest country in the world?",
                options: ["Monaco", "Nauru", "Vatican City", "San Marino"],
                correct: 2
            },
            {
                question: "Which programming language is known for web development?",
                options: ["Python", "JavaScript", "C++", "Java"],
                correct: 1
            },
            {
                question: "What is the hardest natural substance on Earth?",
                options: ["Iron", "Diamond", "Quartz", "Gold"],
                correct: 1
            },
            {
                question: "Which organ in the human body produces insulin?",
                options: ["Liver", "Kidney", "Pancreas", "Heart"],
                correct: 2
            }
        ];
        
        this.currentQuestion = 0;
        this.userAnswers = [];
        this.timer = null;
        this.timeLeft = 600; // 10 minutes default
        this.quizStarted = false;
        
        this.initializeElements();
        this.bindEvents();
        this.showScreen('start-screen');
    }
    
    initializeElements() {
        // Screen elements
        this.startScreen = document.getElementById('start-screen');
        this.quizScreen = document.getElementById('quiz-screen');
        this.resultsScreen = document.getElementById('results-screen');
        this.reviewScreen = document.getElementById('review-screen');
        
        // Control elements
        this.startBtn = document.getElementById('start-btn');
        this.prevBtn = document.getElementById('prev-btn');
        this.nextBtn = document.getElementById('next-btn');
        this.submitBtn = document.getElementById('submit-btn');
        this.restartBtn = document.getElementById('restart-btn');
        this.reviewBtn = document.getElementById('review-btn');
        this.backToResultsBtn = document.getElementById('back-to-results');
        
        // Display elements
        this.timerDisplay = document.getElementById('timer');
        this.scoreDisplay = document.getElementById('score');
        this.questionNumber = document.getElementById('question-number');
        this.questionText = document.getElementById('question-text');
        this.answerOptions = document.getElementById('answer-options');
        this.progress = document.getElementById('progress');
        this.finalScore = document.getElementById('final-score');
        this.scoreDetails = document.getElementById('score-details');
        this.feedbackText = document.getElementById('feedback-text');
        this.reviewContent = document.getElementById('review-content');
        this.quizDuration = document.getElementById('quiz-duration');
    }
    
    bindEvents() {
        this.startBtn.addEventListener('click', () => this.startQuiz());
        this.prevBtn.addEventListener('click', () => this.previousQuestion());
        this.nextBtn.addEventListener('click', () => this.nextQuestion());
        this.submitBtn.addEventListener('click', () => this.submitQuiz());
        this.restartBtn.addEventListener('click', () => this.restartQuiz());
        this.reviewBtn.addEventListener('click', () => this.showReview());
        this.backToResultsBtn.addEventListener('click', () => this.showScreen('results-screen'));
    }
    
    showScreen(screenId) {
        document.querySelectorAll('.screen').forEach(screen => {
            screen.classList.add('hidden');
        });
        document.getElementById(screenId).classList.remove('hidden');
    }
    
    startQuiz() {
        const duration = parseInt(this.quizDuration.value);
        this.timeLeft = duration * 60; // Convert to seconds
        this.currentQuestion = 0;
        this.userAnswers = new Array(this.questions.length).fill(null);
        this.quizStarted = true;
        
        this.showScreen('quiz-screen');
        this.startTimer();
        this.displayQuestion();
        this.updateProgress();
        this.updateScore();
    }
    
    startTimer() {
        this.updateTimerDisplay();
        this.timer = setInterval(() => {
            this.timeLeft--;
            this.updateTimerDisplay();
            
            if (this.timeLeft <= 60) {
                this.timerDisplay.classList.add('warning');
            }
            
            if (this.timeLeft <= 0) {
                this.submitQuiz();
            }
        }, 1000);
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeLeft / 60);
        const seconds = this.timeLeft % 60;
        this.timerDisplay.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    
    displayQuestion() {
        const question = this.questions[this.currentQuestion];
        
        this.questionNumber.textContent = `Question ${this.currentQuestion + 1} of ${this.questions.length}`;
        this.questionText.textContent = question.question;
        
        // Clear previous options
        this.answerOptions.innerHTML = '';
        
        // Create answer options
        question.options.forEach((option, index) => {
            const optionElement = document.createElement('div');
            optionElement.className = 'answer-option';
            optionElement.innerHTML = `
                <span class="option-letter">${String.fromCharCode(65 + index)}</span>
                <span class="option-text">${option}</span>
            `;
            
            optionElement.addEventListener('click', () => this.selectAnswer(index));
            
            // Mark as selected and add feedback if user has already answered
            if (this.userAnswers[this.currentQuestion] === index) {
                optionElement.classList.add('selected');
                
                // Add visual feedback based on correctness
                const correctAnswer = question.correct;
                if (index === correctAnswer) {
                    optionElement.classList.add('correct');
                } else {
                    optionElement.classList.add('incorrect');
                }
            }
            
            this.answerOptions.appendChild(optionElement);
        });
        
        // Update navigation buttons
        this.updateNavigationButtons();
    }
    
    selectAnswer(answerIndex) {
        // Remove previous selection and feedback classes
        this.answerOptions.querySelectorAll('.answer-option').forEach(option => {
            option.classList.remove('selected', 'correct', 'incorrect');
        });
        
        // Mark new selection
        const selectedOption = this.answerOptions.children[answerIndex];
        selectedOption.classList.add('selected');
        
        // Add immediate feedback - correct or incorrect
        const correctAnswer = this.questions[this.currentQuestion].correct;
        if (answerIndex === correctAnswer) {
            selectedOption.classList.add('correct');
        } else {
            selectedOption.classList.add('incorrect');
        }
        
        // Store answer
        this.userAnswers[this.currentQuestion] = answerIndex;
        
        this.updateScore();
    }
    
    updateNavigationButtons() {
        this.prevBtn.disabled = this.currentQuestion === 0;
        
        if (this.currentQuestion === this.questions.length - 1) {
            this.nextBtn.classList.add('hidden');
            this.submitBtn.classList.remove('hidden');
        } else {
            this.nextBtn.classList.remove('hidden');
            this.submitBtn.classList.add('hidden');
        }
    }
    
    previousQuestion() {
        if (this.currentQuestion > 0) {
            this.currentQuestion--;
            this.displayQuestion();
            this.updateProgress();
        }
    }
    
    nextQuestion() {
        if (this.currentQuestion < this.questions.length - 1) {
            this.currentQuestion++;
            this.displayQuestion();
            this.updateProgress();
        }
    }
    
    updateProgress() {
        const progressPercentage = ((this.currentQuestion + 1) / this.questions.length) * 100;
        this.progress.style.width = `${progressPercentage}%`;
    }
    
    updateScore() {
        // Count correct answers in real-time
        let correctAnswers = 0;
        this.userAnswers.forEach((answer, index) => {
            if (answer !== null && answer === this.questions[index].correct) {
                correctAnswers++;
            }
        });
        this.scoreDisplay.textContent = `${correctAnswers}/${this.questions.length}`;
    }
    
    calculateScore() {
        let correct = 0;
        this.userAnswers.forEach((answer, index) => {
            if (answer === this.questions[index].correct) {
                correct++;
            }
        });
        return correct;
    }
    
    submitQuiz() {
        if (this.timer) {
            clearInterval(this.timer);
        }
        
        this.quizStarted = false;
        const score = this.calculateScore();
        const percentage = Math.round((score / this.questions.length) * 100);
        
        this.finalScore.textContent = `${percentage}%`;
        this.scoreDetails.textContent = `You scored ${score} out of ${this.questions.length} questions correctly`;
        
        // Generate feedback
        let feedback = '';
        if (percentage >= 90) {
            feedback = 'Excellent work! You have a strong understanding of the material.';
        } else if (percentage >= 70) {
            feedback = 'Good job! You\'re doing well, but there\'s room for improvement.';
        } else if (percentage >= 50) {
            feedback = 'Not bad, but consider reviewing the material and trying again.';
        } else {
            feedback = 'Keep studying! Practice makes perfect - don\'t give up!';
        }
        
        this.feedbackText.textContent = feedback;
        this.showScreen('results-screen');
    }
    
    showReview() {
        this.reviewContent.innerHTML = '';
        
        this.questions.forEach((question, index) => {
            const reviewElement = document.createElement('div');
            reviewElement.className = 'review-question';
            
            const userAnswer = this.userAnswers[index];
            const correctAnswer = question.correct;
            const isCorrect = userAnswer === correctAnswer;
            
            let answerHTML = '';
            if (userAnswer !== null) {
                if (isCorrect) {
                    answerHTML = `
                        <div class="review-answer correct-user-answer">
                            <strong>Your answer:</strong> ${String.fromCharCode(65 + userAnswer)}. ${question.options[userAnswer]} ✓
                        </div>
                    `;
                } else {
                    answerHTML = `
                        <div class="review-answer user-answer">
                            <strong>Your answer:</strong> ${String.fromCharCode(65 + userAnswer)}. ${question.options[userAnswer]} ✗
                        </div>
                        <div class="review-answer correct-answer">
                            <strong>Correct answer:</strong> ${String.fromCharCode(65 + correctAnswer)}. ${question.options[correctAnswer]} ✓
                        </div>
                    `;
                }
            } else {
                answerHTML = `
                    <div class="review-answer user-answer">
                        <strong>Your answer:</strong> No answer selected ✗
                    </div>
                    <div class="review-answer correct-answer">
                        <strong>Correct answer:</strong> ${String.fromCharCode(65 + correctAnswer)}. ${question.options[correctAnswer]} ✓
                    </div>
                `;
            }
            
            reviewElement.innerHTML = `
                <div class="review-question-text">
                    ${index + 1}. ${question.question}
                </div>
                ${answerHTML}
            `;
            
            this.reviewContent.appendChild(reviewElement);
        });
        
        this.showScreen('review-screen');
    }
    
    restartQuiz() {
        // Clear timer and reset displays
        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }
        
        // Reset timer display and remove warning class
        this.timerDisplay.classList.remove('warning');
        this.timerDisplay.textContent = '10:00';
        
        // Reset score display
        this.scoreDisplay.textContent = '0/0';
        
        // Reset quiz state
        this.currentQuestion = 0;
        this.userAnswers = [];
        this.timeLeft = 600;
        this.quizStarted = false;
        
        this.showScreen('start-screen');
    }
}

// Initialize the quiz application when the page loads
document.addEventListener('DOMContentLoaded', () => {
    new QuizApp();
});